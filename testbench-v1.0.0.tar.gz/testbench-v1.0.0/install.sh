#!/bin/bash
set -e

echo "========================================"
echo "  TestBench 测试管理平台 — 安装向导"
echo "========================================"

INSTALL_DIR="${INSTALL_DIR:-/opt/testbench}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo ""
echo "安装目录: $INSTALL_DIR"
echo ""

# 检测系统
if ! command -v python3 &>/dev/null; then
    echo "错误: 需要 Python 3.11+"
    exit 1
fi

if ! command -v nginx &>/dev/null; then
    echo "警告: 未安装 nginx，前端将无法通过 80 端口访问"
    echo "  安装: apt install nginx  或  yum install nginx"
fi

if ! command -v psql &>/dev/null; then
    echo "警告: 未检测到 PostgreSQL 客户端"
    echo "  确保 PostgreSQL 服务已运行并可连接"
fi

# 创建安装目录
mkdir -p "$INSTALL_DIR"
cp -r "$SCRIPT_DIR/backend" "$INSTALL_DIR/"
cp -r "$SCRIPT_DIR/tests" "$INSTALL_DIR/"
cp -r "$SCRIPT_DIR/docs" "$INSTALL_DIR/"
cp "$SCRIPT_DIR/pyproject.toml" "$INSTALL_DIR/"

# 前端文件
FRONTEND_DIR="${FRONTEND_DIR:-/usr/share/nginx/testbench}"
mkdir -p "$FRONTEND_DIR"
cp -r "$SCRIPT_DIR/frontend-dist/"* "$FRONTEND_DIR/"

# 安装 Python 依赖
echo "安装 Python 依赖..."
cd "$INSTALL_DIR"
if [ -d "$SCRIPT_DIR/packages" ] && [ "$(ls -A "$SCRIPT_DIR/packages" 2>/dev/null)" ]; then
    pip install --no-index --find-links="$SCRIPT_DIR/packages" -e backend/ 2>/dev/null || pip install -e "backend/.[dev]"
else
    pip install -e "backend/.[dev]"
fi

# 配置文件
if [ ! -f "$INSTALL_DIR/.env" ]; then
    cp "$SCRIPT_DIR/.env.example" "$INSTALL_DIR/.env" 2>/dev/null || true
    echo ""
    echo "请编辑配置文件: $INSTALL_DIR/.env"
fi

# nginx 配置
NGINX_CONF="/etc/nginx/conf.d/testbench.conf"
if command -v nginx &>/dev/null && [ ! -f "$NGINX_CONF" ]; then
    cat > "$NGINX_CONF" << NGINX_EOF
server {
    listen 80;
    server_name _;

    location / {
        root $FRONTEND_DIR;
        index index.html;
        try_files \$uri \$uri/ /index.html;
    }

    location /api/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_read_timeout 300s;
    }
}
NGINX_EOF
    echo "nginx 配置已写入: $NGINX_CONF"
fi

# 创建 systemd 服务
SERVICE_FILE="/etc/systemd/system/testbench.service"
if [ ! -f "$SERVICE_FILE" ]; then
    cat > "$SERVICE_FILE" << SERVICE_EOF
[Unit]
Description=TestBench API Server
After=network.target postgresql.service

[Service]
Type=simple
User=$(whoami)
WorkingDirectory=$INSTALL_DIR
EnvironmentFile=$INSTALL_DIR/.env
ExecStart=$(which uvicorn) backend.app.main:app --host 0.0.0.0 --port 8000 --workers 2
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SERVICE_EOF
    echo "systemd 服务已创建: $SERVICE_FILE"
fi

echo ""
echo "========================================"
echo "  安装完成！"
echo "========================================"
echo ""
echo "启动步骤:"
echo "  1. 编辑配置:  vim $INSTALL_DIR/.env"
echo "  2. 初始化数据库: cd $INSTALL_DIR/backend && alembic upgrade head"
echo "  3. 启动后端:  systemctl start testbench"
echo "  4. 启动前端:  systemctl reload nginx"
echo "  5. 访问:      http://$(hostname -I | awk '{print $1}')"
echo ""
echo "默认管理员: admin / admin123"
echo ""
